import java.util.ArrayList;
public class ListAssignment02 {
	public static void main(String[] args) {
		ArrayList<Number> l = new ArrayList<Number>();
		l.add(10);
		l.add(10.5);
		l.add(1.25f);
		//l.add("add");
		System.out.println(l);
	}
}
